#import baie_mom
import time
time.sleep(2)
import dormitor_light